package com.example.iot_matrimony

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
